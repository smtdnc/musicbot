const Discord = require("discord.js");
const conf = require("../configs.json");
exports.run = async (client, message, args) => {
    if (!args[0]) return message.channel.send(new Discord.MessageEmbed()
    .setDescription("Link veya şarkı ismi giiniz")
    .setTitle("Hata!")
    .setColor(conf.errcolor)
    .setFooter(client.user.username + " - v" + conf.version));

    var music = message.content.slice(6);
    if (client.player.isPlaying(message.guild.id)) {
        if (!message.guild.members.cache.get(message.author.id).voice.channel) return message.channel.send(new Discord.MessageEmbed()
        .setDescription("Bir kanalda olmadığın için bu komutu kullanamazsın.")
        .setColor(conf.errcolor)
        .setTitle("Hata!")
        .setFooter(client.user.username + " - v" + conf.version));

        client.player.addToQueue(message.guild.id, music);

        message.channel.send(new Discord.MessageEmbed()
        .setDescription(`\`${music} \` - Kuyruğa eklendi.`)
        .setColor(conf.sucscolor)
        .setTitle("Playlist")
        .setFooter(client.user.username + " - v" + conf.version));
    } else {
        var song = await client.player.play(message.member.voice.channel,music,message.member.user);
        var musicvalue = song.song;

        message.channel.send(new Discord.MessageEmbed()
        .setDescription(`\`${musicvalue.name}\` Şuanda çalıyor...`)
        .setColor(conf.embcolor));
    }
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0,
};

exports.help = {
    name: "play",
    description: "müzik başlatır",
    usage: "play <müzik-ad/link>",
};
