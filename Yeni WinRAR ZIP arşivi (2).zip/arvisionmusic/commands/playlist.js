const Discord = require("discord.js");
const conf = require("../configs.json");
exports.run = async (client, message, args) => {
    if (client.player.isPlaying(message.guild.id) == true) {

        if (!message.guild.members.cache.get(message.author.id).voice.channel) return message.channel.send(new Discord.MessageEmbed()
        .setDescription("Bir kanalda olmadığın için bu komutu kullanamazsın."));

        let queue = await client.player.getQueue(message.guild.id);
        message.channel.send(new Discord.MessageEmbed()
        .setDescription('Çalma listesi:\n' + (queue.songs.map((song, i) => {
            return `${i === 0 ? 'Şuanda oynatılıyor:' : `#${i + 1}`} - ${song.name} | ${song.author}`
        }).join("\n"))));

    } else {
        return message.channel.send(new Discord.MessageEmbed()
        .setDescription("Şuanda bir şarkı çalmıyor.")
        .setColor(conf.errcolor));
    }
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0,
};

exports.help = {
    name: "playlist",
    description: "müzik başlatır",
    usage: "playlist <müzik-ad/link>",
};
