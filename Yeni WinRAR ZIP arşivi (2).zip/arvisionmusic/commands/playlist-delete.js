const Discord = require("discord.js");
const conf = require("../configs.json");
exports.run = async (client, message, args) => {
    if(client.player.isPlaying(message.guild.id) == true) { 
       
        if(!message.guild.members.cache.get(message.author.id).voice.channel) return message.channel.send(new Discord.MessageEmbed()
        .setDescription("Bir kanalda olmadığın için bu komutu kullanamazsın."));
        
        client.player.clearQueue(message.guild.id);
    
        return message.channel.send(new Discord.MessageEmbed()
        .setDescription("Şarkı listesini sıfırladım.")
        .setColor(conf.sucscolor));
        
    } else {
        return message.channel.send(new Discord.MessageEmbed()
        .setDescription("Şuanda bir şarkı çalmıyor.")
        .setColor(conf.errcolor));
    }
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0,
};

exports.help = {
    name: "playlist-clear",
    description: "müzik başlatır",
    usage: "playlist-clear",
};
